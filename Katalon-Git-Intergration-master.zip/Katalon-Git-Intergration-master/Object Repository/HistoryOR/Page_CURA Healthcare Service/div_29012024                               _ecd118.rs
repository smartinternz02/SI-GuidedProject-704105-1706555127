<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_29012024                               _ecd118</name>
   <tag></tag>
   <elementGuidId>1d324701-0916-4182-b371-a0379ec823b4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='history']/div/div[2]/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>a132c5da-db87-4b94-bfba-737084483ec0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value> col-sm-offset-2 col-sm-8</value>
      <webElementGuid>b4894154-3691-4683-af52-3c31ee0ce9c1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                
                    29/01/2024
                    
                        
                            Facility
                        
                        
                            Seoul CURA Healthcare Center
                        
                        

                        
                            Apply for hospital readmission
                        
                        
                            Yes
                        
                        

                        
                            Healthcare Program
                        
                        
                            Medicaid
                        
                        

                        
                            Comment
                        
                        
                            Check history
                        
                    
                
            </value>
      <webElementGuid>8eeba93a-137e-422f-a9a6-c2675b631005</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;history&quot;)/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-offset-2 col-sm-8&quot;]</value>
      <webElementGuid>79cab353-973e-4609-a1ef-cccb192ea169</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='history']/div/div[2]/div</value>
      <webElementGuid>c2021092-6acd-4f98-8df2-07db0f96a08c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div</value>
      <webElementGuid>7addabcb-9c6f-4dc9-8e91-2af34a6917e2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                
                    29/01/2024
                    
                        
                            Facility
                        
                        
                            Seoul CURA Healthcare Center
                        
                        

                        
                            Apply for hospital readmission
                        
                        
                            Yes
                        
                        

                        
                            Healthcare Program
                        
                        
                            Medicaid
                        
                        

                        
                            Comment
                        
                        
                            Check history
                        
                    
                
            ' or . = '
                
                    29/01/2024
                    
                        
                            Facility
                        
                        
                            Seoul CURA Healthcare Center
                        
                        

                        
                            Apply for hospital readmission
                        
                        
                            Yes
                        
                        

                        
                            Healthcare Program
                        
                        
                            Medicaid
                        
                        

                        
                            Comment
                        
                        
                            Check history
                        
                    
                
            ')]</value>
      <webElementGuid>308fcd7d-ed82-46e9-8583-022a8e4f8a31</webElementGuid>
   </webElementXpaths>
</WebElementEntity>

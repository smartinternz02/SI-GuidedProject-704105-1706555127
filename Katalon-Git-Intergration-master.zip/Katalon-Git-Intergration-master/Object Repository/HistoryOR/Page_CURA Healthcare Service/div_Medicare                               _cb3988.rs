<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Medicare                               _cb3988</name>
   <tag></tag>
   <elementGuidId>fbbf582e-9912-4298-b06a-c8a3a7daba66</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='appointment']/div/div/form/div[3]/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>ec78f575-d849-4288-aef6-92bb4db3de33</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>col-sm-4</value>
      <webElementGuid>ffa51a78-4a70-48fc-bf0e-6eb3b47ea809</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                        
                             Medicare
                        
                        
                             Medicaid
                        
                        
                             None
                        
                    </value>
      <webElementGuid>6acacd25-25e5-4ea5-9868-4faf5e4db3b9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;appointment&quot;)/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/form[@class=&quot;form-horizontal&quot;]/div[@class=&quot;form-group&quot;]/div[@class=&quot;col-sm-4&quot;]</value>
      <webElementGuid>8f752669-db7e-4d4f-aa16-c5998c3f2fb6</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='appointment']/div/div/form/div[3]/div</value>
      <webElementGuid>bba8f58a-ae7c-47d0-885c-a0ac80cc7822</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div</value>
      <webElementGuid>7e6bf9bf-9b8e-4bc1-8742-7bded4079a61</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                        
                             Medicare
                        
                        
                             Medicaid
                        
                        
                             None
                        
                    ' or . = '
                        
                             Medicare
                        
                        
                             Medicaid
                        
                        
                             None
                        
                    ')]</value>
      <webElementGuid>2bbfaddc-e42d-4e91-b87b-e37ea9c28fd8</webElementGuid>
   </webElementXpaths>
</WebElementEntity>

<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_19012024                               _1adbc0</name>
   <tag></tag>
   <elementGuidId>58771354-32e3-43db-8212-b57cf0a8b41c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='history']/div/div[2]/div[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>fb3a49c6-b6db-44a4-bc36-17c5dce68a75</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value> col-sm-offset-2 col-sm-8</value>
      <webElementGuid>fc224a4c-41ef-4a21-a5af-5627591845ca</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                
                    19/01/2024
                    
                        
                            Facility
                        
                        
                            Hongkong CURA Healthcare Center
                        
                        

                        
                            Apply for hospital readmission
                        
                        
                            Yes
                        
                        

                        
                            Healthcare Program
                        
                        
                            Medicare
                        
                        

                        
                            Comment
                        
                        
                            2nd appointment
                        
                    
                
            </value>
      <webElementGuid>f360d923-3fd9-4f81-8d2c-e789ee995b94</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;history&quot;)/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-offset-2 col-sm-8&quot;]</value>
      <webElementGuid>90d46097-cd57-4553-bca0-251be050d8ad</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='history']/div/div[2]/div[2]</value>
      <webElementGuid>f904ba90-15fd-4d3d-95ce-2ac22eb7166a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div[2]</value>
      <webElementGuid>f0bb03de-e1af-4908-9d94-0f3e8d375214</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                
                    19/01/2024
                    
                        
                            Facility
                        
                        
                            Hongkong CURA Healthcare Center
                        
                        

                        
                            Apply for hospital readmission
                        
                        
                            Yes
                        
                        

                        
                            Healthcare Program
                        
                        
                            Medicare
                        
                        

                        
                            Comment
                        
                        
                            2nd appointment
                        
                    
                
            ' or . = '
                
                    19/01/2024
                    
                        
                            Facility
                        
                        
                            Hongkong CURA Healthcare Center
                        
                        

                        
                            Apply for hospital readmission
                        
                        
                            Yes
                        
                        

                        
                            Healthcare Program
                        
                        
                            Medicare
                        
                        

                        
                            Comment
                        
                        
                            2nd appointment
                        
                    
                
            ')]</value>
      <webElementGuid>7325161b-862c-4b6f-885a-cb6ca4e815ab</webElementGuid>
   </webElementXpaths>
</WebElementEntity>

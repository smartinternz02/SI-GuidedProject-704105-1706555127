<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_14012024                               _03d2af</name>
   <tag></tag>
   <elementGuidId>be48db7f-107f-4e25-af07-14718b0088d3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='history']/div/div[2]/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>c5fc7396-5825-48c4-810a-7fa484077233</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value> col-sm-offset-2 col-sm-8</value>
      <webElementGuid>28a47bca-b459-4792-9688-20c06eff2a0b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                
                    14/01/2024
                    
                        
                            Facility
                        
                        
                            Seoul CURA Healthcare Center
                        
                        

                        
                            Apply for hospital readmission
                        
                        
                            Yes
                        
                        

                        
                            Healthcare Program
                        
                        
                            Medicaid
                        
                        

                        
                            Comment
                        
                        
                            test
                        
                    
                
            </value>
      <webElementGuid>d8c8f162-8009-49a8-b536-c440d8e5ffd2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;history&quot;)/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-offset-2 col-sm-8&quot;]</value>
      <webElementGuid>d920b8c1-f0e9-4d8a-9782-7d6988372dbb</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='history']/div/div[2]/div</value>
      <webElementGuid>5feeb2e3-2d6e-4263-aefe-103bb5032c42</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div</value>
      <webElementGuid>03b03617-6bc2-4d93-aa30-a521113cfaa2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                
                    14/01/2024
                    
                        
                            Facility
                        
                        
                            Seoul CURA Healthcare Center
                        
                        

                        
                            Apply for hospital readmission
                        
                        
                            Yes
                        
                        

                        
                            Healthcare Program
                        
                        
                            Medicaid
                        
                        

                        
                            Comment
                        
                        
                            test
                        
                    
                
            ' or . = '
                
                    14/01/2024
                    
                        
                            Facility
                        
                        
                            Seoul CURA Healthcare Center
                        
                        

                        
                            Apply for hospital readmission
                        
                        
                            Yes
                        
                        

                        
                            Healthcare Program
                        
                        
                            Medicaid
                        
                        

                        
                            Comment
                        
                        
                            test
                        
                    
                
            ')]</value>
      <webElementGuid>d574ee5c-8c78-4463-9f86-3396fc69c0c3</webElementGuid>
   </webElementXpaths>
</WebElementEntity>

<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>footer_CURA Healthcare Service             _54f5c2</name>
   <tag></tag>
   <elementGuidId>f8288df0-1239-4c2a-b336-b152098694c4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>footer</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//footer</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>footer</value>
      <webElementGuid>ee528fe1-6fee-4e4d-a8ef-d7cd3d9ac3bd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
    
        
            
                CURA Healthcare Service
                
                Atlanta 550 Pharr Road NE Suite 525Atlanta, GA 30305
                
                     (678) 813-1KMS
                     info@katalon.com
                    
                
                
                
                    
                        
                    
                    
                        
                    
                    
                        
                    
                
                
                Copyright © CURA Healthcare Service 2024
            
        
    
    
</value>
      <webElementGuid>00fc70c9-72b7-46c3-a18c-5e06cf4cdd74</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/footer[1]</value>
      <webElementGuid>f1449625-7b38-43d0-8f0c-3c8b2ac83ab4</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//footer</value>
      <webElementGuid>9ecaf300-14c5-40dd-8d5a-206cab92d07e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//footer[(text() = '
    
        
            
                CURA Healthcare Service
                
                Atlanta 550 Pharr Road NE Suite 525Atlanta, GA 30305
                
                     (678) 813-1KMS
                     info@katalon.com
                    
                
                
                
                    
                        
                    
                    
                        
                    
                    
                        
                    
                
                
                Copyright © CURA Healthcare Service 2024
            
        
    
    
' or . = '
    
        
            
                CURA Healthcare Service
                
                Atlanta 550 Pharr Road NE Suite 525Atlanta, GA 30305
                
                     (678) 813-1KMS
                     info@katalon.com
                    
                
                
                
                    
                        
                    
                    
                        
                    
                    
                        
                    
                
                
                Copyright © CURA Healthcare Service 2024
            
        
    
    
')]</value>
      <webElementGuid>e7230cbb-4e60-4716-b29e-32c6480f3595</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
